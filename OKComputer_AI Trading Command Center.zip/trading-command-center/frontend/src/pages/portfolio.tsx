import React from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

export function PortfolioPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Portfolio</h1>
        <p className="text-muted-foreground">
          Track your positions, P&L, and portfolio performance
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Paper Trading Portfolio</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-12 text-muted-foreground">
            <p>Paper trading portfolio is being initialized...</p>
            <p className="text-sm mt-2">Your simulated trades will appear here</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}